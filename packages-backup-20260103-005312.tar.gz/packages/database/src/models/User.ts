import mongoose, { Schema, Model, Document } from 'mongoose';
import bcrypt from 'bcryptjs';

export enum UserRole {
    ADMIN = 'ADMIN',
    USER = 'USER',
}

// Export individual values for use (to avoid unused variable warnings)
// These are used by other modules
export const _ADMIN = UserRole.ADMIN;
export const _USER = UserRole.USER;

export interface IUser extends Document {
    name: string;
    email: string;
    password?: string;
    role: UserRole;
    emailVerified?: Date;
    image?: string;
    resetPasswordToken?: string;
    resetPasswordExpires?: Date;
    // Whitelist mode: usuario necesita aprobación del admin
    approved: boolean;
    approvedAt?: Date;
    approvedBy?: mongoose.Types.ObjectId;
    // Invite-only mode: usuario creado por invitación
    inviteToken?: string;
    inviteExpires?: Date;
    invitedBy?: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
    comparePassword(candidatePassword: string): Promise<boolean>;
}

const userSchema = new Schema<IUser>(
    {
        name: {
            type: String,
            required: [true, 'Name is required'],
            trim: true,
        },
        email: {
            type: String,
            required: [true, 'Email is required'],
            unique: true,
            lowercase: true,
            trim: true,
            match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
        },
        password: {
            type: String,
            minlength: [6, 'Password must be at least 6 characters'],
            select: false, // Don't return password by default
        },
        role: {
            type: String,
            enum: Object.values(UserRole),
            default: UserRole.USER,
        },
        emailVerified: {
            type: Date,
            default: null,
        },
        image: {
            type: String,
            default: null,
        },
        resetPasswordToken: {
            type: String,
            select: false, // Don't return by default
        },
        resetPasswordExpires: {
            type: Date,
            select: false, // Don't return by default
        },
        // Whitelist mode fields
        approved: {
            type: Boolean,
            default: true, // Por defecto aprobado (para backward compatibility)
        },
        approvedAt: {
            type: Date,
            default: null,
        },
        approvedBy: {
            type: Schema.Types.ObjectId,
            ref: 'User',
            default: null,
        },
        // Invite-only mode fields
        inviteToken: {
            type: String,
            select: false,
        },
        inviteExpires: {
            type: Date,
            select: false,
        },
        invitedBy: {
            type: Schema.Types.ObjectId,
            ref: 'User',
            default: null,
        },
    },
    {
        timestamps: true,
    }
);

// Hash password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();

    if (this.password) {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
    }

    next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function (candidatePassword: string): Promise<boolean> {
    if (!this.password) return false;
    return bcrypt.compare(candidatePassword, this.password);
};

// Prevent model recompilation in development
const User: Model<IUser> = mongoose.models.User || mongoose.model<IUser>('User', userSchema);

export default User;
